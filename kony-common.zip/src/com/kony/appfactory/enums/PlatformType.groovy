package com.kony.appfactory.enums

public enum PlatformType implements Serializable {
    ANDROID, IOS
}