package com.kony.appfactory.enums

public enum FormFactor implements Serializable {
    MOBILE_NATIVE, TABLET_NATIVE, UNIVERSAL_NATIVE
}
