package com.kony.appfactory.enums

public enum Status implements Serializable {
    IN_PROGRESS, SUCCESS, FAILED, NA, UNSTABLE, CANCELLED
}