package com.kony.appfactory.enums

public enum BuildType implements Serializable {
    Iris, Foundry
}
